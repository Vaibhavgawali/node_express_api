<?php include 'header.php'; ?>

<div class="breadcrumb-area">
    <div class="breadcrumb-top default-overlay bg-img breadcrumb-overly-3 pt-100 pb-95" style="background-image:url(assets/wallpaper.webp);">
        <div class="container">
            <h2>Catch 25</h2>
            <p>“The expert in anything was once a beginner.” </p>
        </div>
    </div>
    <div class="breadcrumb-bottom">
        <div class="container">
           
        </div>
    </div>
</div>
<div class="event-area pt-130 pb-130">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="blog-details-wrap mr-40">
                    <div class="blog-details-top">
                        <img src="assets/chairman_msg.jpg" alt="">
                        <div class="blog-details-content-wrap">
                           
                            <h3>Success is a dream that stays alive only on the soft pillow of hard work
                            </h3>
                            <p style="text-align: justify;">Realization brings revolution. As a student, recognize your aspirations and the dreams waiting to turn into reality, in the eyes of your parents and well-wishers. The realization will gasoline your every trip into high-quality experiences. Science college students discover, intellectualize, and improvise the world around us. Only You have the doable to develop another Google. You are the one who can develop another vaccine. You can be the next well-known architect. You can be so much!! You can achieve whatever you aspire because you have opted to romance Physics, Chemistry, Mathematics/ Biology.

                                The life of a Student is a Matrix of challenges. 
                                
                                </p>
                            <blockquote>
                                <i class="quote-top fa fa-quote-left"></i>

                                I welcome you with your thoughts to CATCH25 Science Academy, on behalf of my entire team!!
                                <i class="quote-bottom fa fa-quote-right"></i>
                            </blockquote>
                            <p style="text-align: justify;">In the pursuit of completing your Valence shell, to be a Nobleman, be a Principal gene amongst others. No longer be an Alternating Current, but a steady Force. I believe, it’s better to be Unsaturated in your journey, if you are a true student of life. Allow your mind to be the Centripetal pressure acting on all the words of your teachers. Learn to Dissociate the thoughts in your minds into Positives and Negatives ions. Then, Integrate the wonderful ones and Limit the terrible ones. Success desires nothing but, Translation of your ideas into an act. For me, Success is a dream that stays alive only on the soft pillow of tough work.</p>
                            
                        </div>
                    </div>
                   
                    
                    
                   
                </div>
            </div>
            
        </div>
    </div>
</div>
<!-- <div class="brand-logo-area pb-130">
    <div class="container">
        <div class="brand-logo-active owl-carousel">
            <div class="single-brand-logo">
                <a href="#"><img src="assets/img/brand-logo/1.png" alt=""></a>
            </div>
            <div class="single-brand-logo">
                <a href="#"><img src="assets/img/brand-logo/2.png" alt=""></a>
            </div>
            <div class="single-brand-logo">
                <a href="#"><img src="assets/img/brand-logo/3.png" alt=""></a>
            </div>
            <div class="single-brand-logo">
                <a href="#"><img src="assets/img/brand-logo/4.png" alt=""></a>
            </div>
            <div class="single-brand-logo">
                <a href="#"><img src="assets/img/brand-logo/5.png" alt=""></a>
            </div>
            <div class="single-brand-logo">
                <a href="#"><img src="assets/img/brand-logo/6.png" alt=""></a>
            </div>
            <div class="single-brand-logo">
                <a href="#"><img src="assets/img/brand-logo/2.png" alt=""></a>
            </div>
        </div>
    </div>
</div> -->
<?php include 'footer.php'; ?>











