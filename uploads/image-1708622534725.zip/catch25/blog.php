<?php include 'header.php'; ?>

<div class="breadcrumb-area">
    <div class="breadcrumb-top default-overlay bg-img breadcrumb-overly-3 pt-100 pb-95" style="background-image:url(assets/wallpaper.webp);">
        <div class="container">
            <h2>Blog</h2>
            <p>"Dive into our blog and explore a rich tapestry of insights, knowledge, and thought leadership. Stay connected with the latest trends, expert advice, and engaging content that fuels your intellectual curiosity."
</p>
        </div>
    </div>
    
</div>
<div class="event-area pt-130 pb-130">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="blog-all-wrap mr-40">
                    <div class="row">
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="Blog-details.php"><img src="assets/img/blog1.jpg" alt=""></a>
                                </div>
                                <div class="blog-content-wrap">
                                    <div class="blog-content">
                                        <h4><a href="Blog-details.php">"Navigating the Freshman Odyssey: A Guide to Thriving in College"</a></h4>
                                        <p>"Embark on Success: A Fresher’s Manual to Conquering the College Odyssey"</p>
                                        <div class="blog-meta">
                                            
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="Blog-details.php"><img src="assets/img/blog2.jpg" alt=""></a>
                                </div>
                                <div class="blog-content-wrap">
                                    <div class="blog-content">
                                        <h4><a href="Blog-details.php">"From Orientation to Elation: Crafting Unforgettable Memories at the Freshers' Bash".</a></h4>
                                        <p>"Dance, Discover, Delight: Unveiling the Magic of Our Freshers' Bash".</p>
                                        <div class="blog-meta">
                                            
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="Blog-details.php"><img src="assets/img/blog3.jpg" alt=""></a>
                                </div>
                                <div class="blog-content-wrap">
                                 
                                    <div class="blog-content">
                                        <h4><a href="Blog-details.php"> "The Art of Networking: Building Lifelong Connections at the Freshers' Soiree".</a></h4>
                                        <p>"Social Symphony: Crafting Connections at the Fresher's Networking Extravaganza".</p>
                                        <div class="blog-meta">
                                            
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="Blog-details.php"><img src="assets/img/blog4.jpg" alt=""></a>
                                </div>
                                <div class="blog-content-wrap">
                                   
                                    <div class="blog-content">
                                        <h4><a href="Blog-details.php">"Dress to Impress: A Fashionista's Guide to Freshers' Party Glam".</a></h4>
                                        <p>"Runway Ready: Unleashing Your Style Quotient at the Fresher's Fashion Fiesta"</p>
                                        <div class="blog-meta">
                                            
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="Blog-details.php"><img src="assets/img/blog5.jpg" alt=""></a>
                                </div>
                                <div class="blog-content-wrap">
                                    <div class="blog-content">
                                        <h4><a href="Blog-details.php">"Beyond Books: Exploring Extracurriculars and Clubs for Freshers"</a></h4>
                                        <p> "Beyond Classrooms: Unleashing Potential through Extracurricular Marvels".</p>
                                        <div class="blog-meta">
                                            
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="Blog-details.php"><img src="assets/img/blog1.jpg" alt=""></a>
                                </div>
                                <div class="blog-content-wrap">
                                    <div class="blog-content">
                                        <h4><a href="Blog-details.php">"Nurturing Minds, Building Dreams: Insights from Fresher's Orientation".</a></h4>
                                        <p>"Dream Big, Shine Bright: A Glimpse into the Fresher's Orientation Tapestry". </p>
                                        <div class="blog-meta">
                                            
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        
                        
                       
                    </div>
                    
                </div>
            </div>
            
        </div>
    </div>
</div>


<?php include 'footer.php'; ?>














<!-- JS
============================================ -->

<!-- jQuery JS -->
<script src="assets/js/vendor/jquery-v2.2.4.min.js"></script>
<!-- Popper JS -->
<script src="assets/js/popper.min.js"></script>
<!-- Bootstrap JS -->
<script src="assets/js/bootstrap.min.js"></script>
<!-- Plugins JS -->
<script src="assets/js/plugins.js"></script>
<!-- Ajax Mail -->
<script src="assets/js/ajax-mail.js"></script>
<!-- Main JS -->
<script src="assets/js/main.js"></script>

</body>

</html>