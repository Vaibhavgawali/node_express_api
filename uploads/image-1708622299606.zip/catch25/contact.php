<?php include 'header.php'; ?>
<div class="breadcrumb-area">
    <div class="breadcrumb-top default-overlay bg-img breadcrumb-overly-5 pt-100 pb-95" style="background-image:url('assets/wallpaper.webp');">
        <div class="container">
            <h2>Contact Us</h2>
            <p>Reach us at [info@catch25.com] or [022 455 775] for inquiries and assistance.</p>
        </div>
    </div>
    <div class="breadcrumb-bottom">
        <div class="container">
            <ul>
                <li><a href="#"></a> <span></span></li>
            </ul>
        </div>
    </div>
</div>


<div class="register-area bg-img pt-130 pb-130 my-3" style="background-image:url(assets/backimg2.webp);">
    <div class="container">
        <div class="section-title-2 mb-75 white-text">
            <h2>Register <span>Now</span></h2>
            <p>2024 Admission Is Going On. We are announcing  Special discount for 2024 batch.</p>
        </div>
        <div class="register-wrap">
            <div id="register-3" class="mouse-bg">
                <div class="winter-banner">
                    <img src="assets/backimg4.webp" alt="">
                    <div class="winter-content">
                        <span> </span>
                        <h3>2024</h3>
                        <span>ADMISSION </span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-10 col-md-8">
                    <div class="register-form">
                        <h4>Get A free Registration</h4>
                        <form>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="contact-form-style mb-20">
                                        <input name="name" placeholder="First Name" type="text">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="contact-form-style mb-20">
                                        <input name="name" placeholder="Last Name" type="text">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="contact-form-style mb-20">
                                        <input name="name" placeholder="Phone" type="text">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="contact-form-style mb-20">
                                        <input name="name" placeholder="Email" type="text">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                   <div class="contact-form-style mb-20">
                                    <input type="text" placeholder="School-Name">
                                   </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="contact-form-style mb-20">
                                       
                                        <select name="branch" class="form-control" id="branch" placeholder=" " style="height: 46px;border:none;">
                                         
                                        <option value="Mechanical">Select Branch</option>
                                            <option value="Mechanical">Kanidivali</option>
                                            <option value="Civil">Vileparle</option>
                                            <option value="Electronics">Andheri-west</option>
                                            <option value="Automobile">Andheri-East</option>
                                            <option value="Designing">Borivali</option>
                                            
                                        </select> 
                                        
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="contact-form-style">
                                        <textarea name="message" placeholder="Message"></textarea>
                                        <button class="submit default-btn" type="submit">SUBMIT NOW</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="register-1" class="mouse-bg"></div>
    <div id="register-2" class="mouse-bg"></div>
</div>  
<div class="contact-info-area bg-img pt-180 pb-140 default-overlay" style="background-image:url(assets/backimg3.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-12">
                <div class="single-contact-info mb-30 text-center">
                    <div class="contact-info-icon">
                        <span><i class="fa fa-calendar-o"></i></span>
                    </div>
                    <p> 3rd floor, RajMahal, Nr. Mcdonald, Bajaj Road, Opp kandivali station west,<br> Mumbai, Maharashtra 400067.</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-12">
                <div class="single-contact-info mb-30 text-center">
                    <div class="contact-info-icon">
                        <span><i class="fa fa-calendar-o"></i></span>
                    </div>
                    <div class="contact-info-phn">
                        <div class="info-phn-title">
                            <span>Phone : </span>
                        </div>
                        <div class="info-phn-number">
                            <p>022 455 775</p>
                           
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-12">
                <div class="single-contact-info mb-30 text-center">
                    <div class="contact-info-icon">
                        <span><i class="fa fa-calendar-o"></i></span>
                    </div>
                    <a href="#">info@catch25.com</a>
                </div>
            </div>
        </div>
    </div>
</div>


<?php include 'footer.php'; ?>








