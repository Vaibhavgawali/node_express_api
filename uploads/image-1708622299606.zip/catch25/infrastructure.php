<?php include 'header.php'; ?>
<div class="breadcrumb-area">
    <div class="breadcrumb-top default-overlay bg-img breadcrumb-overly-3 pt-100 pb-95" style="background-image:url(assets/wallpaper.webp);">
        <div class="container">
            <h2>Catch25 Infrastructure</h2>
            <p>Immerse yourself in a visual journey through our state-of-the-art infrastructure, where cutting-edge facilities and modern amenities create an optimal environment for learning, collaboration, and personal growth. </p>
        </div>
    </div>
    <div class="breadcrumb-bottom">
        
    </div>
</div>
<div class="event-area pt-130 pb-130" >
    <div class="container " >
        <div class="row ">
            <div class="col-xl-12 col-lg-12">
                <div class="blog-all-wrap mr-40">
                    <div class="row">
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f1.png" alt=""></a>
                                </div>
                                
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f2.png" alt=""></a>
                                </div>
                              
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f3.png" alt=""></a>
                                </div>
                               
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f4.png" alt=""></a>
                                </div>
                               
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f5.png" alt=""></a>
                                </div>
                                
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f6.png" alt=""></a>
                                </div>
                                
                            </div>
                        </div><div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f7.png" alt=""></a>
                                </div>
                               
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f8.png" alt=""></a>
                                </div>
                               
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f9.png" alt=""></a>
                                </div>
                               
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f10.png" alt=""></a>
                                </div>
                                
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f11.png" alt=""></a>
                                </div>
                                
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f2.png" alt=""></a>
                                </div>
                               
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f13.png" alt=""></a>
                                </div>
                               
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f14.png" alt=""></a>
                                </div>
                               
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f15.png" alt=""></a>
                                </div>
                                
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f16.png" alt=""></a>
                                </div>
                               
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f17.png" alt=""></a>
                                </div>
                               
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f18.png" alt=""></a>
                                </div>
                               
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f19.png" alt=""></a>
                                </div>
                               
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f20.png" alt=""></a>
                                </div>
                               
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f21.png" alt=""></a>
                                </div>
                               
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f22.png" alt=""></a>
                                </div>
                                
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f23.png" alt=""></a>
                                </div>
                                
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f24.png" alt=""></a>
                                </div>
                                
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f25.png" alt=""></a>
                                </div>
                                
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f26.png" alt=""></a>
                                </div>
                                
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f27.png" alt=""></a>
                                </div>
                               
                            </div>
                        </div>
                        
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="single-blog mb-30">
                                <div class="blog-img">
                                    <a href="blog-details.html"><img src="assets/f28.png" alt=""></a>
                                </div>
                                
                            </div>
                        </div>
                        
                     
                    </div>
                    
                </div>
            </div>
            
                </div>
            </div> 
        </div>
    


<?php include 'footer.php'; ?>












