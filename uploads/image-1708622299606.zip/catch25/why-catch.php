<?php include 'header.php'; ?>

<div class="breadcrumb-area">
    <div class="breadcrumb-top default-overlay bg-img pt-100 pb-95" style="background-image:url(assets/wallpaper.webp);">
        <div class="container">
            <h2>Why-Catch25</h2>
            <p>"Catch25 are renowned for fostering an environment of excellence, where personalized attention, expert faculty, and innovative teaching methods converge to shape success stories."




</p>
        </div>
    </div>
    <div class="breadcrumb-bottom">
        <div class="container">
            <ul>
                <li><a href="#"></a> <span></span></li>
            </ul>
        </div>
    </div>
</div>
<div class="choose-area bg-img pt-90" style="background-image:url(assets/std5.webp);">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12">
                <div class="about-chose-us pt-120">
                    <div class="row">
                        <div class="col-lg-6 col-md-6">
                            <div class="single-about-chose-us mb-95">
                                <div class="about-choose-img">
                                    <img src="assets/img/icon-img/service-9.png" alt="">
                                </div>
                                <div class="about-choose-content text-light-blue">
                                    <h3>Expert Instructors:</h3>
                                    <p>Emphasize the qualifications, experience, and expertise of your instructors. Highlight any industry experience, advanced degrees. </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="single-about-chose-us mb-95 about-negative-mrg">
                                <div class="about-choose-img">
                                    <img src="assets/img/icon-img/service-10.png" alt="">
                                </div>
                                <div class="about-choose-content text-yellow">
                                    <h3>Interactive Learning Environment: </h3>
                                    <p>Highlight the interactive and engaging nature of your classes. Mention any innovative teaching methods, practical exercises.  </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="single-about-chose-us mb-95">
                                <div class="about-choose-img">
                                    <img src="assets/img/icon-img/service-11.png" alt="">
                                </div>
                                <div class="about-choose-content text-blue">
                                    <h3>Comprehensive Curriculum:</h3>
                                    <p>Showcase the comprehensiveness and relevance of your curriculum. Explain how your classes cover the latest industry trends.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="single-about-chose-us mb-95 about-negative-mrg">
                                <div class="about-choose-img">
                                    <img src="assets/img/icon-img/service-12.png" alt="">
                                </div>
                                <div class="about-choose-content text-green">
                                    <h3>Supportive Learning Resources:
                                    </h3>
                                    <p>Emphasize the additional resources and support systems available to students.
                                         This could include access to a library of online materials.
                                         

                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-12">
                <div class="about-img">
                    <img src="assets/aboutus.jpg" alt="" style="filter:drop-shadow(7px 7px ); padding:20px;" >
                </div>
            </div>
        </div>
    </div>
</div>



<div class="achievement-area pt-130 pb-115">
    <div class="container">
        <div class="section-title mb-75">
            <h2>Catch 25 <span>Success</span></h2>
            <h4>Our Success is in our Students Success</h4>
        </div>
        <div class="testimonial-slider-wrap mt-45">
            <div class="testimonial-text-slider">
                <div class="testi-content-wrap">
                    <div class="testi-big-img">
                        <img alt="" src="assets/janvi.jpg">
                    </div>
                   <div class="row g-0">
                       <div class="ms-auto col-lg-6 col-md-6">
                           <div class="testi-content bg-img default-overlay" style="background-image:url(assets/background.webp);">
                                <div class="quote-style quote-left">
                                   <i class="fa fa-quote-left"></i>
                                </div>
                               <p>Ms Jhanvi Bhandari, a student at the Catch25 Science Academy, batch 2018-2020, presented the KAAVYA - Space Settlement Program project in the US. Project KAAVYA was selected as the 3rd Best Space Settlement Program at the global event, overviewed by NASA, USA. The Catch25 Science Academy has not only developed her skills in physics, chemistry and mathematics but has also made it realize that dreams don't come with a budget. When Prof. Saurabh Patel, Chairman of Catch25 Science Academy, learned of her participation in this global competition, he assigned a separate physics faculty (Prof. Tushar Mondkar) just for her project. </p>
                                <div class="testi-info">
                                   <h5>Ms. Janhavi Bhandari</h5>
                                   <span>Students Of Oxford Public School, 3rd in NASA Ames settlement contest 2019 all over the world.</span>
                                </div>
                                <div class="quote-style quote-right">
                                   <i class="fa fa-quote-right"></i>
                                </div>
                                
                           </div>
                       </div>
                   </div>
                </div>
                
               
               
            </div>
            <div class="testimonial-image-slider">
               
                
            </div>
        </div>
        
    </div>
</div>



    
</div>
<?php include 'footer.php'; ?>










