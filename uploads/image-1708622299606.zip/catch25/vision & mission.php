<?php include 'header.php'; ?>
<div class="breadcrumb-area">
    <div class="breadcrumb-top default-overlay bg-img breadcrumb-overly-2 pt-100 pb-95" style="background-image:url(assets/wallpaper.webp);">
        <div class="container">
            <h2> Vision & Mission</h2>
            <p>"Guided by our unwavering commitment, we aspire to be a beacon of knowledge, fostering innovation and creating a lasting impact on every learner's journey."




</p>
        </div>
    </div>
    <div class="breadcrumb-bottom">
        <div class="container">
            <ul>
                <li><a href="#"></a> <span></span></li>
            </ul>
        </div>
    </div>
</div>
<div class="event-details-area pt-130">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="event-left-wrap mr-40">
                    <div class="event-description">
                        <!-- <div class="description-date-social mb-45">
                            <div class="description-date-time">
                                <div class="description-date">
                                    <span class="event-date">1st</span>
                                    <span>Dec</span>
                                </div>
                                <div class="description-meta-wrap">
                                    <div class="description-meta">
                                        <i class="fa fa-location-arrow"></i>
                                        <span>Mascot Plaza ,Uttara</span>
                                    </div>
                                    <div class="description-meta">
                                        <i class="fa fa-clock-o"></i>
                                        <span>10:30 am</span>
                                    </div>
                                </div>
                            </div>
                            <div class="description-social-wrap">
                                <div class="description-social">
                                    <ul>
                                        <li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
                                        <li><a class="instagram" href="#"><i class="fa fa-instagram"></i></a></li>
                                        <li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a class="google" href="#"><i class="fa fa-google-plus"></i></a></li>
                                    </ul>
                                </div>
                                <div class="description-btn">
                                    <a href="#"><i class="fa fa-share-alt"></i></a>
                                </div>
                            </div>
                        </div> -->
                        <h3 class="text-center">Vision</h3>
                        <img src="assets/vision.jpg" alt="">
                        
                        <p style="text-align: justify; margin-top: 30px;">
                            Our vision is to become an academic found out that works towards the general development of its students by strengthening the brightest and young minds to realize and fly high within the sky so on achieve best in their lives.

At Catch25 science academy, we nurture the scholars to explore their full potential so to boost their self-confidence and moral so as to understand their dreams by advanced teaching methodology.

At Catch25 science academy, students gain an understanding of the courses they enrol for and obtain mentorship in career directions while enhancing the tutorial process as they become a subsequent generation of execs who are getting t
o run the country’s economy and steer it towards growth and prosperity.
                        </p>
                        
                        <div class="event-gallery text-center mt-40">
                            <h3>Mission</h3>
                            <div class="event-gallery-active nav-style-3 owl-carousel">
                                <img src="assets/mission.jpg" alt="">
                                
                            </div>
                            <p style="text-align: justify;margin-top: 30px;margin-bottom:30px">Our mission is to deliver quality education to every and each student and to make sure his or her success. We commit ourselves to excellent education and boast of a variety of college members who are totally devoted and committed so on build trust and compassion between teachers and students and make sure that the scholars achieve what they came for.

                            </p>
                        </div>
                        <!-- <div class="seat-book-wrap bg-img mt-80 " style="background-image:url(assets/img/event/seat-book.jpg);">
                            <div class="seat-book-title text-center">
                                <h3>Book Your Seat Now</h3>
                                <p> natus error sit voluptatem accu antium dolorem laudantium, totam rem aperiam, eaque entore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
                            </div>
                            <div class="seat-book-form">
                                <form>
                                    <div class="row">
                                        <div class="col-lg-6 col-md-6">
                                            <input placeholder="Name" type="text">
                                        </div>
                                        <div class="col-lg-6 col-md-6">
                                            <input placeholder="Email" type="email">
                                        </div>
                                        <div class="col-lg-6 col-md-6">
                                            <input name="name" placeholder="Date" type="text">
                                        </div>
                                        <div class="col-lg-6 col-md-6">
                                            <input placeholder="Time" type="text">
                                        </div>
                                        <div class="col-lg-12">
                                            <textarea placeholder="Message"></textarea>
                                            <button class="seat-book-btn" type="submit">BOOK NOW</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div> -->
                        <!-- <div class="location-area mt-80">
                            <div id="location"></div>
                        </div> -->
                    </div>
                </div>
            </div>
          
        </div>
    </div>
</div>
<?php include 'footer.php'; ?>











