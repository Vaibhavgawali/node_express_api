const popupForm =()=>
{
    return `
    <div class="form-popup-bg">
  <div class="form-container">
    <button id="btnCloseForm" class="close-button text-success" style ="font-size:1.5rem;">X</button>

  <div class="row">
        <div class="col-md-8 col-lg-8">
            <div class="mt-5 mt-sm-0">
              <button class="join-btn mt-5 mt-sm-0">Register Now</button>
            </div>
            <h2 class="text-dark pt-3">2024 Admission Is Going On. We are announcing Special discount for 2024 batch.</h3>

            <h1 class="pt-4 nest-style" style="font-family: Georgia, serif;">NEST</h1>
        </div>

          <div class="col-md-4 col-lg-4">
           <img class="d-none d-sm-block" src="assets/img/stud.jpg" alt="" height="230px" width="100%">
          </div>
    </div>
   
    <div class="d-flex align-items-center align-items-sm-start flex-column flex-sm-row">

     <div>
     <div class="row pt-4">
        <div class="col-md-5 col-lg-5">
           <input class="border border-dark form-control" type="text" id="fname" name="fname" class="form-control" placeholder="First Name" required />
        </div>
 
        <div class="col-md-5 col-lg-5 mt-3 mt-sm-0">
           <input class="border border-dark form-control" type="text" id="lname" name="lname" class="form-control" placeholder="Last Name" required />
        </div>
     </div>
 
     <div class="row">
        <div class="col-md-5 col-lg-5 mt-3">
           <input class="border border-dark form-control" type="email" id="lname" name="lname" class="form-control" placeholder="Email ID" required />
        </div>
 
        <div class="col-md-5 col-lg-5 mt-3">
           <input class="border border-dark form-control" type="number" id="lname" name="lname" class="form-control" placeholder="Phone number" required />
        </div>
     </div>

     <div class="row">
        <div class="col-md-5 col-lg-5 mt-3">
           <input class="border border-dark form-control" type="email" id="lname" name="lname" class="form-control" placeholder="School Name" required />
        </div>
        <div class="col-md-5 col-lg-5 mt-3">

        <select id="" name="" class="form-control border border-dark">
            <option value="" selected disabled>--Select Branch--</option>
            <option value="">Kandivali</option>
            <option value="">Vileparle</option>
            <option value="">Andheri-West</option>
            <option value="">Andheri-East</option>
            <option value="">Borivali</option>

        </select>
        </div>
     </div>
     <div class="row">
        <div class="col-md-10 col-lg-10">
            <div class="pt-3">
                <textarea id="message" name="message" rows="4" class="form-control border border-dark" cols="50" placeholder="Message"></textarea>
               </div>
        </div>
     </div>
    

     </div>
 
     <div class="p-4">
        <button class="sub-button popup-btn  pt-3 pb-3 px-4 my-4 my-sm-0">Join Us</button>
     </div>

  </div>
    
  </div>
</div>
    `
}

let mobileMenu = $('#mobile-menu');


$('#popupform').html(popupForm());

function closeForm() {
    $('.form-popup-bg').removeClass('is-visible');
  }
  
  $(document).ready(function($) {
    
  
  setTimeout(function() {
mobileMenu.css('display', 'none');

          $('.form-popup-bg').addClass('is-visible');
      }, 2000); 
    
      
    $('.form-popup-bg').on('click', function(event) {
mobileMenu.css('display', 'block');

      if ($(event.target).is('.form-popup-bg') || $(event.target).is('#btnCloseForm')) {
        event.preventDefault();
        $(this).removeClass('is-visible');
      }
    });
    
    
    



});
