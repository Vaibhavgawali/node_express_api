<?php include 'header.php'; ?>


<div class="breadcrumb-area">
    <div class="breadcrumb-top default-overlay bg-img breadcrumb-overly-2 pt-100 pb-95" style="background-image:url(assets/wallpaper.webp);">
        <div class="container">
            <h2>Catch25 Courses </h2>
            <p>"Explore our diverse range of courses designed to inspire learning and empower your future success."




</p>
        </div>
    </div>
    <div class="breadcrumb-bottom">
        <div class="container">
            <ul>
                <li><a href="#"></a> <span></span></li>
            </ul>
        </div>
    </div>
</div>
<div class="course-area bg-img pt-130">
    <div class="container">
        <div class="section-title mb-75 course-mrg-small">
            <h2> <span>IIT-</span>JEE </h2>
            <p>"IIT-JEE: A rigorous crucible where academic prowess meets resilience, forging the brightest minds for excellence in engineering and technology."
</p>
        </div>
        <div class="course-slider-active-3">
            <div class="single-course">
                <div class="course-img">
                    <a href="IIT-JEE.php"><img class="animated" src="assets/1.jpg" alt=""></a>
                </div>
                <div class="course-content">
                </div>
               
            </div>
            <div class="single-course">
                <div class="course-img">
                    <a href="IIT-JEE.php"><img class="animated" src="assets/2.jpg" alt=""></a>
                </div>
                <div class="course-content">
                </div>
               
            </div>
            <div class="single-course">
                <div class="course-img">
                    <a href="IIT-JEE.php"><img class="animated" src="assets/3.jpg" alt=""></a>
                </div>
                <div class="course-content">
                </div>
                
            </div> <div class="single-course">
                <div class="course-img">
                    <a href="IIT-JEE.php"><img class="animated" src="assets/4.jpg" alt=""></a>
                </div>
                <div class="course-content">
                </div>
            
            
        </div>
    </div>
</div>
<div class="course-area bg-img">
    <div class="container">
        <div class="section-title mb-75 course-mrg-small">
            <h2>  <span>NEET</span></h2>
            <p>"NEET: The pivotal gateway to medical aspirations, where knowledge meets compassion, shaping the future healers of tomorrow."
</p>
        </div>
        <div class="course-slider-active-4">
            <div class="single-course">
                <div class="course-img">
                    <a href="NEET.php"><img class="animated" src="assets/5.jpg" alt=""></a>
                </div>
                <div class="course-content">
                </div>
                
            </div>
            <div class="single-course">
                <div class="course-img">
                    <a href="NEET.php"><img class="animated" src="assets/6.jpg" alt=""></a>
                </div>
                <div class="course-content">
                </div>
               
            </div>
            <div class="single-course">
                <div class="course-img">
                    <a href="NEET.php"><img class="animated" src="assets/7.jpg" alt=""></a>
                </div>
                <div class="course-content">
                </div>
               
            </div>
            <div class="single-course">
                <div class="course-img">
                    <a href="NEET.php"><img class="animated" src="assets/8.jpg" alt=""></a>
                </div>
                <div class="course-content">
                </div>
               
            </div>
           
        </div>
    </div>
</div>
<div class="course-area bg-img">
    <div class="container">
        <div class="section-title mb-75 course-mrg-small">
            <h2> <span>NATA</span> </h2>
            <p>"NATA: Bridging creativity and architecture, a competitive realm where design acumen takes center stage in shaping the visionaries of architectural innovation."</p>

        </div>
        <div class="course-slider-active-5">
            <div class="single-course">
                <div class="course-img">
                    <a href="NATA.php"><img class="animated" src="assets/3.jpg" alt=""></a>
                </div>
                <div class="course-content">
                </div>
               
            </div>
            <div class="single-course">
                <div class="course-img">
                    <a href="NATA.php"><img class="animated" src="assets/10.jpg" alt=""></a>
                </div>
                <div class="course-content">
                </div>
               
            </div>
            <div class="single-course">
                <div class="course-img">
                    <a href="NATA.php"><img class="animated" src="assets/11.jpg" alt=""></a>
                </div>
                <div class="course-content">
                </div>
                
            </div>
            <div class="single-course">
                <div class="course-img">
                    <a href="NATA.php"><img class="animated" src="assets/12.jpg" alt=""></a>
                    
                </div>
               
                
            </div>
            
        </div>
    </div>
</div><div class="course-area bg-img">
    <div class="container">
        <div class="section-title mb-75 course-mrg-small">
            <h2> <span>11th-12th Board</span> </h2>
            <p>"11th and 12th boards: The defining chapters in the academic narrative, where students sculpt their educational trajectory and pave the way for future endeavors."</p>





        </div>
        <div class="course-slider-active-5">
            <div class="single-course">
                <div class="course-img">
                    <a href="11-12-BOARD.php"><img class="animated" src="assets/5.jpg" alt=""></a>
                </div>
                <div class="course-content">
                </div>
               
            </div>
            <div class="single-course">
                <div class="course-img">
                    <a href="11-12-BOARD.php"><img class="animated" src="assets/13.jpg" alt=""></a>
                </div>
                <div class="course-content">
                </div>
               
            </div>
            <div class="single-course">
                <div class="course-img">
                    <a href="11-12-BOARD.php"><img class="animated" src="assets/18.jpg" alt=""></a>
                </div>
                <div class="course-content">
                </div>
                
            </div>
            <div class="single-course">
                <div class="course-img">
                    <a href="11-12-BOARD.php"><img class="animated" src="assets/20.jpg" alt=""></a>
                    
                </div>
               
                
            </div>
            
        </div>
    </div>
</div>
<!-- <div class="brand-logo-area pb-130">
    <div class="container">
        <div class="brand-logo-active owl-carousel">
            <div class="single-brand-logo">
                <a href="#"><img src="assets/img/brand-logo/1.png" alt=""></a>
            </div>
            <div class="single-brand-logo">
                <a href="#"><img src="assets/img/brand-logo/2.png" alt=""></a>
            </div>
            <div class="single-brand-logo">
                <a href="#"><img src="assets/img/brand-logo/3.png" alt=""></a>
            </div>
            <div class="single-brand-logo">
                <a href="#"><img src="assets/img/brand-logo/4.png" alt=""></a>
            </div>
            <div class="single-brand-logo">
                <a href="#"><img src="assets/img/brand-logo/5.png" alt=""></a>
            </div>
            <div class="single-brand-logo">
                <a href="#"><img src="assets/img/brand-logo/6.png" alt=""></a>
            </div>
            <div class="single-brand-logo">
                <a href="#"><img src="assets/img/brand-logo/2.png" alt=""></a>
            </div>
        </div>
    </div>
</div> -->

<?php include 'footer.php'; ?>













