<?php include 'header.php'; ?>


<div class="breadcrumb-area">
    <div class="breadcrumb-top default-overlay bg-img pt-100 pb-95" style="background-image:url(assets/wallpaper.webp);">
        <div class="container">
            <h2>About Us</h2>
            <p>"Discover the story behind our institute, our mission, and the passionate individuals driving excellence in education."




</p>
        </div>
    </div>
    <div class="breadcrumb-bottom">
        <div class="container">
            <ul>
                <li><a href="#"></a> <span> </span></li>
            </ul>
        </div>
    </div>
</div>
<div class="choose-area bg-img pt-90" style="background-image:url(assets/std5.webp);">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12">
                <div class="about-chose-us pt-120">
                    <div class="row">
                        <div class="col-lg-6 col-md-6">
                            <div class="single-about-chose-us mb-95">
                                <div class="about-choose-img">
                                    <img src="assets/img/icon-img/service-9.png" alt="">
                                </div>
                                <div class="about-choose-content text-light-blue">
                                    <h3>Scholarship Facility</h3>
                                    <p>magna aliqua. Ut enim ad minim veniam conse ctetur adipisicing elit, sed do exercitation ullamco</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="single-about-chose-us mb-95 about-negative-mrg">
                                <div class="about-choose-img">
                                    <img src="assets/img/icon-img/service-10.png" alt="">
                                </div>
                                <div class="about-choose-content text-yellow">
                                    <h3>Best Teacher </h3>
                                    <p>magna aliqua. Ut enim ad minim veniam conse ctetur adipisicing elit, sed do exercitation ullamco</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="single-about-chose-us mb-95">
                                <div class="about-choose-img">
                                    <img src="assets/img/icon-img/service-11.png" alt="">
                                </div>
                                <div class="about-choose-content text-blue">
                                    <h3>Library & Book Store</h3>
                                    <p>magna aliqua. Ut enim ad minim veniam conse ctetur adipisicing elit, sed do exercitation ullamco</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="single-about-chose-us mb-95 about-negative-mrg">
                                <div class="about-choose-img">
                                    <img src="assets/img/icon-img/service-12.png" alt="">
                                </div>
                                <div class="about-choose-content text-green">
                                    <h3>25 Years Of Experience</h3>
                                    <p>magna aliqua. Ut enim ad minim veniam conse ctetur adipisicing elit, sed do exercitation ullamco</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-12">
                <div class="about-img">
                    <img src="assets/aboutus.jpg" alt="" style="filter:drop-shadow(7px 7px ); padding:20px;" >
                </div>
            </div>
        </div>
    </div>
</div>
<!-- <div class="video-area bg-img pt-270 pb-270" style="background-image:url(assets/img/banner/video.jpg);">
    <div class="video-btn-2">
        <a class="video-popup" href="https://www.youtube.com/watch?v=sv5hK4crIRc">
            <img class="animated" src="assets/img/icon-img/viddeo-btn.png" alt="">
        </a>
    </div>
</div> -->

<div class="fun-fact-area bg-img pt-130 pb-100" style="background-image:url(assets/moni.webp);">
    <div class="container">
        <div class="section-title-3 section-shape-hm2-2 white-text text-center mb-100">
            <h2><span>Fun</span> Fact</h2>
            <p>tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, <br> quis nostrud exercitation ullamco laboris nisi ut aliquip </p>
        </div>
        <div class="row">
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                <div class="single-count mb-30 count-one count-white">
                    <div class="count-img">
                        <img src="assets/img/icon-img/funfact-1.png" alt="">
                    </div>
                    <div class="count-content">
                        <h2 class="count">160</h2>
                        <span>AWARD WINNING</span>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                <div class="single-count mb-30 count-two count-white">
                    <div class="count-img">
                        <img src="assets/img/icon-img/funfact-2.png" alt="">
                    </div>
                    <div class="count-content">
                        <h2 class="count">200</h2>
                        <span>GRADUATE</span>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-3 col-md-6 col-sm-6">
                <div class="single-count mb-30 count-three count-white">
                    <div class="count-img">
                        <img src="assets/img/icon-img/funfact-1.png" alt="">
                    </div>
                    <div class="count-content">
                        <h2 class="count">160</h2>
                        <span>AWARD WINNING</span>
                    </div>
                </div>
            </div>
            <div class="col-xl-2 col-lg-3 col-md-6 col-sm-6">
                <div class="single-count mb-30 count-four count-white">
                    <div class="count-img">
                        <img src="assets/img/icon-img/funfact-2.png" alt="">
                    </div>
                    <div class="count-content">
                        <h2 class="count">200</h2>
                        <span>FACULTIES</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="achievement-area pt-130 pb-115">
    <div class="container">
        <div class="section-title mb-75">
            <h2>What <span>People Say</span></h2>
            <p> where testimonials speak volumes, echoing the transformative impact of our institute in fostering knowledge, growth, and success. </p>
        </div>
        <div class="testimonial-slider-wrap mt-45">
            <div class="testimonial-text-slider">
                <div class="testi-content-wrap">
                    <div class="testi-big-img">
                        <img alt="" src="assets/saurabh.jpg">
                    </div>
                   <div class="row g-0">
                       <div class="ms-auto col-lg-6 col-md-6">
                           <div class="testi-content bg-img default-overlay" style="background-image:url(assets/background.webp);">
                                <div class="quote-style quote-left">
                                   <i class="fa fa-quote-left"></i>
                                </div>
                                <p>The life of a Student is a Matrix of challenges. In the pursuit of completing your Valence shell, to be a Nobleman, be a Principal gene amongst others. No longer be an Alternating Current, but a steady Force. I believe, it’s better to be Unsaturated in your journey, if you are a true student of life. Allow your mind to be the Centripetal pressure acting on all the words of your teachers. Learn to Dissociate the thoughts in your minds into Positives and Negatives ions. </p>
                                <div class="testi-info">
                                   <h5>Prof.Saurabh Patel</h5>
                                   <span>Director of Catch25 Science Academy and Maths Lecturer</span>
                                </div>
                                <div class="quote-style quote-right">
                                   <i class="fa fa-quote-right"></i>
                                </div>
                              
                           </div>
                       </div>
                   </div>
                </div>
                <div class="testi-content-wrap">
                   <div class="testi-big-img">
                        <img alt="" src="assets/Mrs.Saurabh.jpg">
                    </div>
                   <div class="row g-0">
                        <div class="ms-auto col-lg-6 col-md-6">
                           <div class="testi-content bg-img default-overlay" style="background-image:url(assets/img/bg/testi.png);">
                                <div class="quote-style quote-left">
                                   <i class="fa fa-quote-left"></i>
                                </div>
                                <p>
                                Realization brings revolution. As a student, recognize your aspirations and the dreams waiting to turn into reality, in the eyes of your parents and well-wishers. The realization will gasoline your every trip into high-quality experiences. Science college students discover, intellectualize, and improvise the world around us. Only You have the doable to develop another Google. You are the one who can develop another vaccine. You can be the next well-known architect. You can be so much!! You can achieve whatever you aspire because you have opted to romance Physics, Chemistry, Mathematics/ Biology.

</p>
                                <div class="testi-info">
                                   <h5>Mrs.Yashika Patel</h5>
                                   <span>CEO. Catch25</span>
                                </div>
                                <div class="quote-style quote-right">
                                   <i class="fa fa-quote-right"></i>
                                </div>
                                
                           </div>
                       </div>
                   </div>
                </div>
                <div class="testi-content-wrap">
                    <div class="testi-big-img">
                        <img alt="" src="assets/img/testimonial/testi-b2.jpg">
                    </div>
                   <div class="row g-0">
                        <div class="ms-auto col-lg-6 col-md-6">
                           <div class="testi-content bg-img default-overlay" style="background-image:url(assets/img/bg/testi.png);">
                                <div class="quote-style quote-left">
                                   <i class="fa fa-quote-left"></i>
                                </div>
                               <p>Lorem ipsum dolor sit amet, conse ctetur adipi sicing elit, sed do eiusm od tempor incidi dunt ut labore et dolore magna aliqua. Ut enim  fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui. Sed ut perspiciatis unde omnis iste natus error sit </p>
                                <div class="testi-info">
                                   <h5>Robiul siddikee</h5>
                                   <span>Students Of AMMT Department</span>
                                </div>
                                <div class="quote-style quote-right">
                                   <i class="fa fa-quote-right"></i>
                                </div>
                                <div class="testi-arrow">
                                    <img alt="" src="assets/img/icon-img/testi-icon.png">
                                </div>
                           </div>
                        </div>
                   </div>
                </div>
                <div class="testi-content-wrap">
                   <div class="testi-big-img">
                        <img alt="" src="assets/img/testimonial/testi-b2.jpg">
                    </div>
                    <div class="row g-0">
                       <div class="ms-auto col-lg-6 col-md-6">
                           <div class="testi-content bg-img default-overlay" style="background-image:url(assets/img/bg/testi.png);">
                                <div class="quote-style quote-left">
                                   <i class="fa fa-quote-left"></i>
                                </div>
                               <p>Lorem ipsum dolor sit amet, conse ctetur adipi sicing elit, sed do eiusm od tempor incidi dunt ut labore et dolore magna aliqua. Ut enim  fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit </p>
                                <div class="testi-info">
                                   <h5>Modhu Dada</h5>
                                   <span>Students Of AMMT Department</span>
                                </div>
                                <div class="quote-style quote-right">
                                   <i class="fa fa-quote-right"></i>
                                </div>
                                <div class="testi-arrow">
                                    <img alt="" src="assets/img/icon-img/testi-icon.png">
                                </div>
                           </div>
                       </div>
                   </div>
                </div>
            </div>
            <div class="testimonial-image-slider">
                <div class="sin-testi-image">
                    <img src="assets/saurabh.jpg" alt="">
                </div>
                <div class="sin-testi-image">
                    <img src="assets/Mrs.Saurabh.jpg" alt="">
                </div>
                
            </div>
        </div>
       
    </div>
</div>

<div class="teacher-area  pb-100 " >
    <div class="container ">
        <div class="section-title mb-75">
            <h2>Best <span>Teacher</span></h2>
            <p>"At [Catch25], excellence is personified in our best teachers. Their passion for teaching goes beyond the syllabus, creating an inspiring atmosphere where students flourish, and futures are shaped."




</p>
        </div>
        <h2 class="text-center">Maths Teacher</h2>

        <div class="custom-row   d-flex align-items-center justify-content-center">
            <div class="custom-col-5">
                <div class="single-teacher mb-30">
                    <div class="teacher-img">
                        <img src="assets/t1.webp" alt="">
                    </div>
                    <div class="teacher-content-visible">
                        <h4>Prof. Saurabh Patel</h4>
                      
                    </div>
                    <div class="teacher-content-wrap">
                        <div class="teacher-content">
                        <h5>B.E Elex. , M.Tech. EXTC</h5>
                            
                            <p>►13+ years of Teaching and 4 years of Industry Experience.
►Director of Catch25 Science Academy.</p>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="custom-col-5">
                <div class="single-teacher mb-30">
                    <div class="teacher-img">
                        <img src="assets/t2.webp" alt="">
                    </div>
                    <div class="teacher-content-visible">
                        <h4>Prof.Pawan Bharadwaj
</h4>
                   
                    </div>
                    <div class="teacher-content-wrap">
                        <div class="teacher-content">
                            <h5>B.E.Chem

</h5>
                            <p>►18+ years of Teaching Experience.►Master of Geometry.</p>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="custom-col-5">
                <div class="single-teacher mb-30">
                    <div class="teacher-img">
                        <img src="assets/t3.webp" alt="">
                    </div>
                    <div class="teacher-content-visible">
                        <h4>Prof.Sagar Parekh
</h4>
                  
                    </div>
                    <div class="teacher-content-wrap">
                        <div class="teacher-content">
                            <h5>Msc Maths

</h5>
                            <p>► Total 5+ years of teaching experience.
► 4+ years of teaching experience in engineering colleges & 11th 12th JEE.
</p>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="custom-col-5">
                <div class="single-teacher mb-30">
                    <div class="teacher-img">
                        <img src="assets/t4.webp" alt="">
                    </div>
                    <div class="teacher-content-visible">
                        <h4>Prof. Pradeep Yadav
</h4>
                  
                    </div>
                    <div class="teacher-content-wrap">
                        <div class="teacher-content">
                            <h5>M.E. EXTC

</h5>
                            <p>► 11+ years of teaching experience in 11th & 12th JEE.
► Professor of DJ Sanghvi College.</p>
                            
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</div>
<hr>
<div class="teacher-area  pb-100 " >
    <div class="container ">
       
        <h2 class="text-center">Chemistry Teacher</h2>

        <div class="custom-row   d-flex align-items-center justify-content-center">
            <div class="custom-col-5">
                <div class="single-teacher mb-30">
                    <div class="teacher-img">
                        <img src="assets/t1.webp" alt="">
                    </div>
                    <div class="teacher-content-visible">
                        <h4>Prof. Amul Desai
</h4>
                      
                    </div>
                    <div class="teacher-content-wrap">
                        <div class="teacher-content">
                        <h5>PhD in Chemistry.

</h5>
                            
                            <p>► 25+ years of Teaching Experience.► Master in JEE advanced and Entrance examinations.</p>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="custom-col-5">
                <div class="single-teacher mb-30">
                    <div class="teacher-img">
                        <img src="assets/t2.webp" alt="">
                    </div>
                    <div class="teacher-content-visible">
                        <h4>Prof. Vinita Shirke</h4>
                   
                    </div>
                    <div class="teacher-content-wrap">
                        <div class="teacher-content">
                            <h5>B.E/M.E.Chem.</h5>
                            <p>►9+ years of Teaching Experience.
►Faculty of reputed Institute.</p>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="custom-col-5">
                <div class="single-teacher mb-30">
                    <div class="teacher-img">
                        <img src="assets/t3.webp" alt="">
                    </div>
                    <div class="teacher-content-visible">
                        <h4>Prof. Preetesh Mishra</h4>
                  
                    </div>
                    <div class="teacher-content-wrap">
                        <div class="teacher-content">
                            <h5>M.Pharm.</h5>
                            <p>► 7+ years of Teach, Experience.
► Worked in Medical Affairs and Clinical Research Dept</p>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="custom-col-5">
                <div class="single-teacher mb-30">
                    <div class="teacher-img">
                        <img src="assets/t4.webp" alt="">
                    </div>
                    <div class="teacher-content-visible">
                        <h4>Prof.Mehtab Khan
</h4>
                  
                    </div>
                    <div class="teacher-content-wrap">
                        <div class="teacher-content">
                            <h5>M.Pharm.</h5>
                            <p>►8+ years of Teaching Experience.► Clinical Practice at NIDA Clinical Trials Network.</p>
                            
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</div>
<hr>
<div class="teacher-area  pb-100 " >
    <div class="container ">
        <h2 class="text-center">Physics Teacher</h2>
        <div class="custom-row   d-flex align-items-center justify-content-center">
            <div class="custom-col-5">
                <div class="single-teacher mb-30">
                    <div class="teacher-img">
                        <img src="assets/t1.webp" alt="">
                    </div>
                    <div class="teacher-content-visible">
                        <h4>Prof. Nyraj Vasani</h4>
                      
                    </div>
                    <div class="teacher-content-wrap">
                        <div class="teacher-content">
                        <h5>M.Tech</h5>
                            
                            <p>►11+ years of extensive teaching experience.</p>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="custom-col-5">
                <div class="single-teacher mb-30">
                    <div class="teacher-img">
                        <img src="assets/t2.webp" alt="">
                    </div>
                    <div class="teacher-content-visible">
                        <h4>Prof. Ravindra Parabhu</h4>
                   
                    </div>
                    <div class="teacher-content-wrap">
                        <div class="teacher-content">
                            <h5>M.Tech</h5>
                            <p>►20+ years of Teaching Experience with All Big IIT institutes.</p>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="custom-col-5">
                <div class="single-teacher mb-30">
                    <div class="teacher-img">
                        <img src="assets/t3.webp" alt="">
                    </div>
                    <div class="teacher-content-visible">
                        <h4>Prof. Aatish Rane</h4>
                  
                    </div>
                    <div class="teacher-content-wrap">
                        <div class="teacher-content">
                            <h5>B.E. Mech</h5>
                            <p>►7+ years of Teaching & Working Experience.</p>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="custom-col-5">
                <div class="single-teacher mb-30">
                    <div class="teacher-img">
                        <img src="assets/t4.webp" alt="">
                    </div>
                    <div class="teacher-content-visible">
                        <h4>Prof.Nitin Jaiswal</h4>
                  
                    </div>
                    <div class="teacher-content-wrap">
                        <div class="teacher-content">
                            <h5>B.E. Mech</h5>
                            <p>►Working with Godrej at Quality & Design.</p>
                            
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</div>
<hr>
<div class="teacher-area  pb-100 " >
    <div class="container ">
    <h2 class="text-center">Biology Teacher</h2>

        <div class="custom-row   d-flex align-items-center justify-content-center">
            <div class="custom-col-5">
                <div class="single-teacher mb-30">
                    <div class="teacher-img">
                        <img src="assets/t1.webp" alt="">
                    </div>
                    <div class="teacher-content-visible">
                        <h4>Prof. Preetesh Mishra</h4>
                      
                    </div>
                    <div class="teacher-content-wrap">
                        <div class="teacher-content">
                        <h5>M.Pharm</h5>
                            
                            <p>► 7+ years of Teach, Experience.</p>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="custom-col-5">
                <div class="single-teacher mb-30">
                    <div class="teacher-img">
                        <img src="assets/t2.webp" alt="">
                    </div>
                    <div class="teacher-content-visible">
                        <h4>Prof. Shiba Sukumaran</h4>
                   
                    </div>
                    <div class="teacher-content-wrap">
                        <div class="teacher-content">
                            <h5>M.Sc.</h5>
                            <p>►7+ years of teaching experience for IGCSE board.</p>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="custom-col-5">
                <div class="single-teacher mb-30">
                    <div class="teacher-img">
                        <img src="assets/t3.webp" alt="">
                    </div>
                    <div class="teacher-content-visible">
                        <h4>Dr. Sachidanand Dubey</h4>
                  
                    </div>
                    <div class="teacher-content-wrap">
                        <div class="teacher-content">
                            <h5>BAMS</h5>
                            <p>►6 Years of Teaching experience to NEET Students.</p>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="custom-col-5">
                <div class="single-teacher mb-30">
                    <div class="teacher-img">
                        <img src="assets/t4.webp" alt="">
                    </div>
                    <div class="teacher-content-visible">
                        <h4>Prof.Dr Ela Atheaya</h4>
                  
                    </div>
                    <div class="teacher-content-wrap">
                        <div class="teacher-content">
                            <h5>PHD</h5>
                            <p>►16+ years of experience in teaching field.►Worked as a PGT biology in CBSE school.</p>
                            
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</div>
<!-- <div class="brand-logo-area pb-130">
    <div class="container">
        <div class="brand-logo-active owl-carousel">
            <div class="single-brand-logo">
                <a href="#"><img src="assets/img/brand-logo/1.png" alt=""></a>
            </div>
            <div class="single-brand-logo">
                <a href="#"><img src="assets/img/brand-logo/2.png" alt=""></a>
            </div>
            <div class="single-brand-logo">
                <a href="#"><img src="assets/img/brand-logo/3.png" alt=""></a>
            </div>
            <div class="single-brand-logo">
                <a href="#"><img src="assets/img/brand-logo/4.png" alt=""></a>
            </div>
            <div class="single-brand-logo">
                <a href="#"><img src="assets/img/brand-logo/5.png" alt=""></a>
            </div>
            <div class="single-brand-logo">
                <a href="#"><img src="assets/img/brand-logo/6.png" alt=""></a>
            </div>
            <div class="single-brand-logo">
                <a href="#"><img src="assets/img/brand-logo/2.png" alt=""></a>
            </div>
        </div>
    </div>
</div> -->


<?php include 'footer.php'; ?>












