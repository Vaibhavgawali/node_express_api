<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Catch25 IIT&JEE Coaching</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/catch25_fevicon.png">
    
    <!-- CSS
	============================================ -->
   
    <!-- Bootstrap CSS -->
    <!-- <link rel="stylesheet" href="assets/css/bootstrap.min.css"> -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">

    <!-- Icon Font CSS -->
    <link rel="stylesheet" href="assets/css/icons.min.css">
    <!-- Plugins CSS -->
    <link rel="stylesheet" href="assets/css/plugins.css">
    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr-3.11.7.min.js"></script>
    <style>
        .modal-custom-width {
            max-width: 30%; /* Adjust the value to your preferred width */
        }
    </style>
</head>

<body>
    <header class="header-area">
        <div class="header-top bg-img" style="background-image:url(assets/img/icon-img/header-shape.png);">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-7 col-12 col-sm-8">
                        <div class="header-contact">
                           
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-5 col-12 col-sm-4">
                        <div class="login-register">
                            <ul>
                                <li><a href="login-register.php">Login</a></li>
                                <li><a href="login-register.php">Register</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-bottom sticky-bar clearfix">
            <div class="container">
                <div class="row">
                    <div class="col-lg-2 col-md-6 col-4">
                        <div class="logo">
                            <a href="index.html">
                                <img alt="" src="assets/img/event//Catch25-logo-01.png" width="150px">
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-10 col-md-6 col-8">
                        <div class="menu-cart-wrap">
                            <div class="main-menu">
                                <nav>
                                    <ul>
                                        <li><a href="index.php"> HOME </a>
                                            
                                        </li> 
                                    
                                        <li><a href="#"> ABOUT <i class="fa fa-angle-down"></i> </a>
                                            <ul class="submenu">
                                                <li><a href="about-us.php">About-us</a></li>
                                                
                                                <li><a href="chairmanm.php">Chairman's Message</a></li>
                                                <li><a href="vision & mission.php">Vision & Mission </a></li>
                                                <li><a href="why-catch.php">Why Catch-25</a></li>
                                                <li><a href="infrastructure.php">Infrastructure</a></li>

                                            
                                            </ul>
                                        </li>
                                        <li class="mega-menu-position top-hover"><a href="course.php">Courses<i class="fa fa-angle-down"></i> </a>
                                            <ul class="mega-menu">
                                                <li>
                                                    <ul>
                                                        
                                                        <li><a href="">NEET</a></li>
                                                        <li><a href="NEET.php">Pre-Medical(NEET-UG) </a></li>
                                                    
                                                    </ul>
                                                </li>
                                                <li>
                                                    <ul>
                                                        <li><a href="">IIT-JEE</a></li>
                                                        <li><a href="IIT-JEE.php">JEE(MAIN+ADVANCE)</a></li>
                                                        
                                                    </ul>
                                                </li>
                                                <li>
                                                    <ul>
                                                        <li><a href="">11th-12th Boards</a></li>
                                                        <li><a href="11-12-BOARD.php">MHT-CET</a></li>
                                                        
                                                    </ul>
                                                </li>
                                                <li>
                                                    <ul>
                                                        
                                                        <li><a href="">NATA</a></li>
                                                        <li><a href="NATA.php">JEE(MAIN)</a></li>
                                                    
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>
                                    
                                        <!-- <li><a href="">why catch25</a></li> -->
                                        <!-- <li><a href="">Centers</a>
                                            <ul class="submenu">
                                                <li><a href="">center 1</a></li>
                                                <li><a href="">center 2</a></li>
                                            </ul>
                                        </li> -->
                                        <li><a href="blog.php"> Blog </a></li>
                                         <li><a href="contact.php"> CONTACT </a></li>
                                    </ul>
                                </nav>
                            </div>
                           
                        </div>
                    </div>
                </div>
                <div class="mobile-menu-area">
                    <div class="mobile-menu">
                        <nav id="mobile-menu-active">
                            <ul class="menu-overflow">
                                <li><a href="">HOME</a>
                                
                                </li>
                                <li><a href=""></a></li>
                                
                                <li><a href="course.html">Courses/program</a>
                                    <ul>
                                        <li><a href="#">Commarce</a>
                                            <ul>
                                                <li><a href="">JEE( Main+ Advance) IIT-JEE</a></li>
                                                <li><a href="">JEE(Main)</a></li>
                                                <li><a href="">Pre-Medical(NEET-UG)</a></li>
                                                <li><a href="">IIT-JEE</a></li>
                                                <li><a href="">IIT-JEE</a></li>
                                                <li><a href="">MAH-CET</a></li>
                                                <li><a href="">NEET</a></li>
                                                <li><a href="">NATA</a></li>
                                                <li ><a href="">JEE( Main+ Advance) IIT-JEE</a></li>
                                                <li><a href="">Commarce</a></li>
                                                <li><a href="">JEE( Main+ Advance) IIT-JEE</a></li>
                                                <li><a href="">JEE(Main)</a></li>
                                                <li><a href="">Pre-Medical(NEET-UG)</a></li>
                                                <li ><a href="">JEE( Main+ Advance) IIT-JEE</a></li>
                                                <li><a href="">11th-12th Boards</a></li>
                                                <li><a href="">MAH-CET</a></li>
                                                <li><a href="">NEET</a></li>
                                                <li><a href="">NATA</a></li>
                                                
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                            
                                <li><a href="">Why catch25</a></li>
                                <li><a href="">centers</a>
                                    <ul>
                                        <li><a href="">center 1</a></li>
                                        <li><a href="">center 2</a></li>
                                    </ul>
                                </li>
                                <li><a href="">Contact</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>  
    </header>