<?php include 'header.php'; ?>

<div class="breadcrumb-area">
    <div class="breadcrumb-overly-2 pt-100 pb-95 ing-fluid mt-1" style="background-image:url(assets/img/wallp2.jpg);">
        <!-- <div class="container">
            <h2>Course Grid</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore .</p>
        </div> -->
    </div>
    <!-- <div class="breadcrumb-bottom">
        <div class="container">
            <ul>
                <li><a href="#">Home</a> <span><i class="fa fa-angle-double-right"></i>Course Grid</span></li>
            </ul>
        </div>
    </div> -->
</div>
<div class="course-details-area pt-130">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="course-left-wrap mr-40">
                    <div class="apply-area">
                        <img src="assets/neet.jpg" alt="">
                        
                    </div>
                    <div class="course-tab-list nav pt-40 pb-25 mb-35">
                        <a class="active" href="#course-details-1" data-bs-toggle="tab" >

                        </a>
                        <a href="#course-details-2" data-bs-toggle="tab">
                            
                        </a>
                        <a href="#course-details-3" data-bs-toggle="tab">
                    
                        </a>
                    </div>
                    <div class="tab-content jump">
                        <div class="tab-pane active" id="course-details-1">
                            <div class="over-view-content">
                               <h1>National Eligibility cum Entrance Test (NEET)</h1>
                                <p>The National Eligibility cum Entrance Test (NEET) is an entrance examination in India for students who wish to study undergraduate medical courses (MBBS) and dental courses (BDS) in government or private medical and dental colleges in India. Students who have passed 10+2 or equivalent with Physics, Chemistry, Biology/Biotechnology and English as core subjects from a recognized board are eligible to apply for NEET

                                    
                              
                                <div class="course-details-img">
                                    <img src="assets/img/neet.jpg" alt="">
                                    <div class="course-apply-btn text-center my-3">
                                        <a href="contact.php" class="default-btn">APPLY NOW</a>
                                    </div>
                                </div>
                                <div class="course-summary-wrap">
                                    
                                    
                                    
                                    
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="course-details-2">
                            <div class="over-view-content">
                               
                                <h5>Head Of The Department  : Ara’af Imtiaz</h5>
                                <p>magna aliqua. Ut enim ad minim veniam, nisi ut aliquiptempor incid.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi m aperiam, eaque ipsa quae abaspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
                                <div class="over-view-list">
                                    <div class="sin-over-view-list">
                                        <div class="course-list-icon">
                                            <i class="fa fa-check"></i> .
                                        </div>
                                        <div class="course-list-content">
                                            <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet,</p>
                                        </div>
                                    </div>
                                    <div class="sin-over-view-list">
                                        <div class="course-list-icon">
                                            <i class="fa fa-check"></i> .
                                        </div>
                                        <div class="course-list-content">
                                            <p> Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet,</p>
                                        </div>
                                    </div>
                                    <div class="sin-over-view-list">
                                        <div class="course-list-icon">
                                            <i class="fa fa-check"></i> .
                                        </div>
                                        <div class="course-list-content">
                                            <p>Es eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="course-details-img">
                                    <img src="assets/img/neet.jpg" alt="">
                                </div>
                                <div class="course-summary-wrap">
                                    <div class="single-course-summary">
                                        <h4>Total Students</h4>
                                        <span><i class="fa fa-user"></i> 50</span>
                                    </div>
                                    <div class="single-course-summary">
                                        <h4>Course Duration</h4>
                                        <span><i class="fa fa-clock-o"></i> 4yrs</span>
                                    </div>
                                    <div class="single-course-summary">
                                        <h4>Course Credits</h4>
                                        <span><i class="fa fa-diamond"></i> 125</span>
                                    </div>
                                    <div class="single-course-summary">
                                        <h4>Total Semester</h4>
                                        <span><i class="fa fa-book"></i> 12</span>
                                    </div>
                                </div>
                                <p>magna aliqua. Ut enim ad minim veniam, nisi ut aliquiptempor incid.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi m aperiam, eaque ipsa quae abaspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
                            </div>
                        </div>
                        <div class="tab-pane" id="course-details-3">
                            <div class="review-wrapper">
                                <div class="single-review">
                                    <div class="review-img">
                                        <img src="assets/img/blog/recent-post-1.jpg" alt="">
                                    </div>
                                    <div class="review-content">
                                        <div class="review-top-wrap">
                                            <div class="review-left">
                                                <div class="review-name">
                                                    <h4>White Lewis</h4>
                                                </div>
                                                <div class="review-rating">
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                </div>
                                            </div>
                                            <div class="review-btn">
                                                <a href="#">Reply</a>
                                            </div>
                                        </div>
                                        <div class="review-bottom">
                                            <p>Vestibulum ante ipsum primis aucibus orci luctustrices posuere cubilia Curae Suspendisse viverra ed viverra. Mauris ullarper euismod vehicula. Phasellus quam nisi, congue id nulla nec, convallis conval lis leo. Maecenas bibendum bibendum larius.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="single-review child-review">
                                    <div class="review-img">
                                        <img src="assets/img/blog/recent-post-2.jpg" alt="">
                                    </div>
                                    <div class="review-content">
                                        <div class="review-top-wrap">
                                            <div class="review-left">
                                                <div class="review-name">
                                                    <h4>White Lewis</h4>
                                                </div>
                                                <div class="review-rating">
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                </div>
                                            </div>
                                            <div class="review-btn">
                                                <a href="#">Reply</a>
                                            </div>
                                        </div>
                                        <div class="review-bottom">
                                            <p>Vestibulum ante ipsum primis aucibus orci luctustrices posuere cubilia Curae Suspendisse viverra ed viverra. Mauris ullarper euismod vehicula. Phasellus quam nisi, congue id nulla nec, convallis conval lis leo. Maecenas bibendum bibendum larius.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="ratting-form-wrapper">
                                <h3>Add a Review</h3>
                                <div class="ratting-form">
                                    <form>
                                        <div class="star-box">
                                            <span>Your rating:</span>
                                            <div class="ratting-star">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="rating-form-style mb-20">
                                                    <input placeholder="Name" type="text">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="rating-form-style mb-20">
                                                    <input placeholder="Email" type="email">
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="rating-form-style form-submit">
                                                    <textarea name="Your Review" placeholder="Message"></textarea>
                                                    <input type="submit" value="Submit">
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                  
                </div>
            </div>
            
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>












